## Sky Void Worldgen (Default)
The `skyvoid_worldgen` data pack generates an infinite void world with properties akin to the original SkyBlock. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
