## Vanilla One Block Starter
The `skyvoid_vanilla_oneblock_starter` data pack facilitates the initial grind at the beginning of [One Block](https://github.com/BPR02/SkyBlock_Collection/wiki/Vanilla-One-Block). For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
